# Wanderer

[![icon.png](https://i.postimg.cc/dtw04z35/icon.png)](https://postimg.cc/8sXDCXhv)

# Skills

[![Screenshot-2024-09-15-053840.png](https://i.postimg.cc/FHjV9sZB/Screenshot-2024-09-15-053840.png)](https://postimg.cc/QFdTmDvQ)

# Airblade

With an enemy airborne, use Utility, buffer Secondary during the dash, then press Special before the spin fires. The buffered spin follows Last Breath to its destination. 

# 

Check out my other mods:

https://thunderstore.io/c/riskofrain2/p/tsuyoikenko/

Contact me on Discord: https://discord.gg/GKFCa8z2y8

Currently needs skill icons

# Credits

tsuyoikenko - Everything.

Redacted - Whirlwind Skin.

Zebra - Has exploded. Goodbye.

orbeezeater - Referenced baseline code for skills from deprecated yasuo mod

TheTimeSweeper - Incredible new Henry template.