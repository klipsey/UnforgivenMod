# Wanderer

[![icon.png](https://i.postimg.cc/dtw04z35/icon.png)](https://postimg.cc/8sXDCXhv)

# Skills

[![Screenshot-2024-06-23-223404.png](https://i.postimg.cc/9QBd1rTz/Screenshot-2024-06-23-223404.png)](https://postimg.cc/3kd0xrtH)

Check out my other mods:

https://thunderstore.io/package/tsuyoikenko/Scout/

https://thunderstore.io/package/tsuyoikenko/Seamstress/

https://thunderstore.io/package/tsuyoikenko/Spy/

https://thunderstore.io/package/tsuyoikenko/Interrogator/

Contact me on Discord: https://discord.gg/3NaMEsvYeD

# Credits

tsuyoikenko - Everything.

Zebra - Has exploded. Goodbye.

orbeezeater - Skills base code taken from deprecated Yasuo mod.

TheTimeSweeper - Incredible new Henry template.

rob - Creator of the glorious Henry template.