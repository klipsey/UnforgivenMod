# 0.5.3

- Fixed dash not damaging for clients
- Fixed team damage on melee

# 0.5.2

- Quick cleanup

# 0.5.1

- Networked

# 0.5.0

- Zebra removed, animations are free

# 0.1.3

- Updated Read Me

# 0.1.2

- Insane amount of smoothing and gameplay fixes

# 0.1.1

- Missed some stuff

# 0.1.0

- First release
- 0 networking