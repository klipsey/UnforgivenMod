# 0.8.9

- Jumping item thing fixed

# 0.8.8

- Fixed for the collective

# 0.8.7

- Please.

# 0.8.6

- Fixed emotesapi compat

# 0.8.5

- Fixed Camera Params

# 0.8.4

- Doubled Melee hitbox ranges
- Increased hithop velocity 

# 0.8.3

- Fixed for SOTS v3

# 0.8.2

- Fixed for SOTS

# 0.8.1 

- Tokens

# 0.8.0

- Added Ragdoll

# 0.7.2

- No more console spam

# 0.7.1

- Sots fixes

# 0.7.0 

- Added Whirlwind Skin

# 0.6.7

- Fixed some math 

# 0.6.6

- Enabled scepter

# 0.6.5

- Added hardlight compat

# 0.6.4

- Spin 

# 0.6.3

- Cooldown buffed for secondary to match with mercenary

# 0.6.2

- Networking

# 0.6.1

- Sprinting consistency

# 0.6.0

- Keyblade, beyblade whatever now works (animation cancel also works)
- If util is casted and secondary is at a 0.5 second cooldown it will now refresh like in league
- Nerfed dash damage
- Added sheathing during runs and sprints
- Lmk if networking has broken cause of the changes

# 0.5.9

- Fixed invincibility thing
- Fixed some anims
- Uh need to fix keyblading, its a bit screwed up rn

# 0.5.8

- Scepter no icon

# 0.5.7

- Stab hitbox is more stabbier

# 0.5.6

- Fixed some item displays
- Fixed swing animation
- Fixed tornado animation

# 0.5.5

- Bubble size

# 0.5.4

- Hopefully fixed client lag later in game?
- Hopefully fixed special demolishing the game

# 0.5.3

- Fixed dash not damaging for clients
- Fixed team damage on melee

# 0.5.2

- Quick cleanup

# 0.5.1

- Networked

# 0.5.0

- Zebra removed, animations are free

# 0.1.3

- Updated Read Me

# 0.1.2

- Insane amount of smoothing and gameplay fixes

# 0.1.1

- Missed some stuff

# 0.1.0

- First release
- 0 networking