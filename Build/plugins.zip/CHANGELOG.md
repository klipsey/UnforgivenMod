# 0.1.2

- Insane amount of smoothing and gameplay fixes

# 0.1.1

- Missed some stuff

# 0.1.0

- First release
- 0 networking